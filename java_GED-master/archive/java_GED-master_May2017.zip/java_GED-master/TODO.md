# TODO list
## Dynamic cost calculation
- make a configuration for dynamic cost
- make a class that calculate the dynamic cost
- output the cost in a separate file with the score output
## HED with structural matching
- The structural takes an extra argument for radius.
- Add radius to the configuration 
- make a class of HED that calculate the Str-radius.


