/**
 * 
 */
package util;

import java.util.LinkedList;

/**
 * @author riesen
 *
 */
@SuppressWarnings("serial")
public class GraphSet extends LinkedList<Graph>{
	// dummy class 
}
