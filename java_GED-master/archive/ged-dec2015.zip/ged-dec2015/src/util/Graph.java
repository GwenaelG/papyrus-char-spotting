/**
 * 
 */
package util;

import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author riesen
 *
 */
@SuppressWarnings("serial")
public class Graph extends LinkedList<Node>{

	/** the full identifier of this graph including class id, index in the cxl, and file name */
	private String fullId; //andreas
	
	/** the class of this graph */
	private String className;
	
	/** the identifier of the graph */
	private String graphID;
	
	/** directed or undirected edges */
	private boolean directed;
		
	/** the adjacency-matrix of the graph */
	private Edge[][] adjacencyMatrix;

	
	
	
	/**
	 * Constructors
	 */
	public Graph(int n) {
		super();
		this.adjacencyMatrix = new Edge[n][n];
	}
	
	public Graph() {
		super();
	}
	
	/** 
	 * generates a printable string of the graph
	 */
	public String toString(){
		String graph = "*** Graph: "+this.graphID+" ***\n";
		graph += "Class: "+this.className+"\n";
		graph += "Nodes:\n";
		Iterator<Node> iter = this.iterator();
		while (iter.hasNext()){
			Node node = iter.next();
			graph += node.toString();
			graph += "\n";
		}
		graph += "\n";
		graph += "Edges of...\n";
		for (int i=0; i < size(); i++) {
			Node node = get(i);
			graph+="... Node: "+node.getNodeID()+": ";
			Iterator<Edge> edgeIter = adjEdges(i).iterator();
			while (edgeIter.hasNext()){
				Edge edge = edgeIter.next();
				graph+=edge.getEdgeID()+"\t";
			}
			graph+="\n";
		}
		graph += "\n";
		graph += "Adjacency Matrix:\n";
		for (int i = 0; i < this.adjacencyMatrix.length; i++){
			for (int j = 0; j < this.adjacencyMatrix.length; j++){
				if (this.adjacencyMatrix[i][j] != null){
					graph += "1";
				} else {
					graph += "0";
				}
				
				graph += "\t";
			}
			graph += "\n";
		}
		graph+="\n*** *** *** *** *** *** *** *** *** *** *** *** *** ***\n";
		return graph;
	}
	



	/**
	 * getters and setters
	 */

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getGraphID() {
		return graphID;
	}

	public void setGraphID(String graphID) {
		this.graphID = graphID;
	}

	public boolean isDirected() {
		return directed;
	}

	public void setDirected(boolean directed) {
		this.directed = directed;
	}

	public Edge[][] getAdjacenyMatrix() {
		return adjacencyMatrix;
	}

	public void setAdjacenyMatrix(Edge[][] edges) {
		this.adjacencyMatrix = edges;
	}
	
	//andreas
	
	public Edge adjEdge(int i, int j) {
		if (adjacencyMatrix[i][j] != null) {
			return adjacencyMatrix[i][j];
		} else {
			return adjacencyMatrix[j][i];
		}
	}
	
	public int adjEdgeDegree(int idx) {
		int deg = 0;
		for (int i=0; i < adjacencyMatrix.length; i++) {
			if (adjacencyMatrix[idx][i] != null) {
				deg++;
			}
			if (directed && adjacencyMatrix[i][idx] != null) {
				deg++;
			}
		}
		return deg;
	}
	
	public LinkedList<Edge> adjEdges(int idx) {
		LinkedList<Edge> edges = new LinkedList<Edge>();
		for (int i=0; i < adjacencyMatrix.length; i++) {
			if (adjacencyMatrix[idx][i] != null) {
				edges.add(adjacencyMatrix[idx][i]);
			}
			if (directed && adjacencyMatrix[i][idx] != null) {
				edges.add(adjacencyMatrix[i][idx]);
			}
		}
		return edges;
	}
	
	public LinkedList<Integer> adjNeighborIdxs(int idx) {
		LinkedList<Integer> neighbors = new LinkedList<Integer>();
		for (int i=0; i < adjacencyMatrix.length; i++) {
			if (adjacencyMatrix[idx][i] != null) {
				neighbors.add(i);
			}
			if (directed && adjacencyMatrix[i][idx] != null) {
				neighbors.add(i);
			}
		}
		return neighbors; 
	}
	
	public String getFullId() {
		return fullId;
	}

	public void setFullId(String fullId) {
		this.fullId = fullId;
	}
	
	public LinkedList<Edge> getOutgoingEdges(int idx) {
		LinkedList<Edge> edges = new LinkedList<Edge>();
		for (int i=0; i < adjacencyMatrix.length; i++) {
			if (adjacencyMatrix[idx][i] != null) {
				edges.add(adjacencyMatrix[idx][i]);
			}
		}
		return edges;
	}
	
	public LinkedList<Edge> getIncomingEdges(int idx) {
		LinkedList<Edge> edges = new LinkedList<Edge>();
		for (int i=0; i < adjacencyMatrix.length; i++) {
			if (adjacencyMatrix[i][idx] != null) {
				edges.add(adjacencyMatrix[i][idx]);
			}
		}
		return edges;
	}
	
	public Edge getEdge(int idx1, int idx2) {
		return adjacencyMatrix[idx1][idx2];
	}
	
	public int[] getOutgoingEdgeEndings(int idx1) {
		return getEdgeEndings(idx1, true);
	}
	
	public int[] getIncomingEdgeEndings(int idx1) {
		return getEdgeEndings(idx1, false);
	}
	
	public int[] getEdgeEndings(int idx1, boolean isOutgoing) {
		LinkedList<Integer> list = new LinkedList<Integer>();
		for (int i=0; i < adjacencyMatrix.length; i++) {
			if (isOutgoing && adjacencyMatrix[idx1][i] != null) {
				list.add(i);
			} else if (!isOutgoing && adjacencyMatrix[i][idx1] != null) {
				list.add(i);
			}
		}
		int[] idxs = new int[list.size()];
		for (int i=0; i < list.size(); i++) {
			idxs[i] = list.get(i);
		}
		return idxs;
	}
	
	public Edge getEdge(int idx1, int idx2, boolean isOutgoing) {
		if (isOutgoing) {
			return adjacencyMatrix[idx1][idx2];
		}
		return adjacencyMatrix[idx2][idx1];
	}

}
