package andreas;

import util.CostFunction;

public abstract class AStarHeuristic {

	protected AStarGraph g1;
	protected AStarGraph g2;
	protected CostFunction cf;
	
	public AStarHeuristic(AStarGraph g1, AStarGraph g2, CostFunction cf) {
		this.g1 = g1;
		this.g2 = g2;
		this.cf = cf;
	}
	
	public abstract void heuristicFunction(AStarMap map);
	
}
