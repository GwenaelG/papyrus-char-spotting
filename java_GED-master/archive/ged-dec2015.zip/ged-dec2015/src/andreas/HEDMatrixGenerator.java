package andreas;

import util.CostFunction;
import util.Graph;

public class HEDMatrixGenerator {

	/**
	 * |         |
	 * | c_i,j   | del
	 * |_________|______
	 * |         |
	 * |  ins    |	0
	 * |         |
	 */
	public double[][] getHEDContextMatrix(Graph sourceGraph, Graph targetGraph, CostFunction cf, int radius) {		
		int sSize = sourceGraph.size();
		int tSize = targetGraph.size();
		int dim = sSize + tSize;
		double[][] matrix = new double[dim][dim];
		
		// HED costs
		
		HEDContext hed = new HEDContext(sourceGraph, targetGraph, cf, radius);
		double[][] contextCosts = hed.generateContextCostMatrix();
		
		// sub
		
		for (int i = 0; i < sSize; i++) {
			for (int j = 0; j < tSize; j++) {
				matrix[i][j] = contextCosts[i][j];
			}
		}
		
		// ins

		for (int i = sSize; i < dim; i++) {
			for (int j = 0; j < tSize; j++) {
				matrix[i][j] = contextCosts[sSize][j];
			}
		}
		
		// del
		
		for (int i = 0; i < sSize; i++) {
			for (int j = tSize; j < dim; j++) {
				matrix[i][j] = contextCosts[i][tSize];
			}
		}
		
		// zero

		for (int i = sSize; i < dim; i++) {
			for (int j = tSize; j < dim; j++) {
				matrix[i][j] = 0.0;
			}
		}
		
		return matrix;
	}
	
}
